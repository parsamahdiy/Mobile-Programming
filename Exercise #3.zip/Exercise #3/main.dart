import 'dart:io';

void main() {
  List<String> shoppingList = [];

  print("Enter 5 items for your shopping list:");

  for (int i = 0; i < 5; i++) {
    stdout.write("Item ${i + 1}: ");

    String item = stdin.readLineSync()!;

    shoppingList.add(item);
  }

  print("\nYour shopping list:");

  for (int i = 0; i < shoppingList.length; i++) {
    print("${i + 1}. ${shoppingList[i]}");
  }
}
