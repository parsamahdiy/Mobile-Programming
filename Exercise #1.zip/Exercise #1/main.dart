import 'dart:io';

void main() {
  stdout.write('نام خود را وارد کنید: ');
  String? name = stdin.readLineSync();

  stdout.write('نام خانوادگی خود را وارد کنید: ');
  String? family = stdin.readLineSync();

  stdout.write('شماره خود را وارد کنید: ');
  String? phone = stdin.readLineSync();

  stdout.write('سن خود را وارد کنید: ');
  String? age = stdin.readLineSync();

  print('\n----- مشخصات فرد -----');

  print('نام: $name');
  print('نام خانوادگی: $family');
  print('شماره: $phone');
  print('سن: $age');
}
